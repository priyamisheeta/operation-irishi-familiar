package com.operationirishi.familiar

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar
import kotlin.random.Random

object CheckInScheduler {
    private const val REQUEST_CODE = 4101

    fun scheduleNext(context: Context) {
        val now = System.currentTimeMillis()
        val randomDelay = Random.nextLong(90L, 241L) * 60_000L
        var trigger = now + randomDelay
        val c = Calendar.getInstance().apply { timeInMillis = trigger }
        val hour = c.get(Calendar.HOUR_OF_DAY)
        if (hour >= 22 || hour < 7) {
            if (hour >= 22) c.add(Calendar.DAY_OF_YEAR, 1)
            c.set(Calendar.HOUR_OF_DAY, 8)
            c.set(Calendar.MINUTE, Random.nextInt(0, 46))
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            trigger = c.timeInMillis
        }
        val intent = Intent(context, CheckInReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, REQUEST_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(AlarmManager::class.java)
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
    }

    fun cancel(context: Context) {
        val pending = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            Intent(context, CheckInReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        ) ?: return
        context.getSystemService(AlarmManager::class.java).cancel(pending)
        pending.cancel()
    }
}
