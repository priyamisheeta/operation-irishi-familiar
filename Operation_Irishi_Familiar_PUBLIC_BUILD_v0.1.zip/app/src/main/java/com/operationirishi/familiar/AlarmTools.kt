package com.operationirishi.familiar

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object AlarmTools {
    fun scheduleStudyEnd(context: Context, whenMillis: Long) {
        val intent = Intent(context, StudyAlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(context, 4201, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        context.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pi)
    }

    fun cancelStudyEnd(context: Context) {
        val pi = PendingIntent.getBroadcast(
            context, 4201, Intent(context, StudyAlarmReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        ) ?: return
        context.getSystemService(AlarmManager::class.java).cancel(pi)
        pi.cancel()
    }

    fun schedulePromise(context: Context, whenMillis: Long) {
        val intent = Intent(context, PromiseReceiver::class.java)
        val pi = PendingIntent.getBroadcast(context, 4202, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        context.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pi)
    }
}
