package com.operationirishi.familiar

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var refreshToken by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = AppStore(this)
        store.installedAt
        NotificationKit.ensureChannels(this)
        CheckInScheduler.scheduleNext(this)
        store.completeStudyIfDue()

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 900)
        }

        setContent {
            FamiliarTheme {
                FamiliarApp(refreshToken = refreshToken, onRefresh = { refreshToken++ })
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshToken++
    }
}

@Composable
private fun FamiliarTheme(content: @Composable () -> Unit) {
    val scheme = androidx.compose.material3.darkColorScheme(
        primary = Color(0xFFB9A7E8),
        secondary = Color(0xFFD7C9F4),
        tertiary = Color(0xFF9DCDE3),
        background = Color(0xFF17151C),
        surface = Color(0xFF211E29),
        surfaceVariant = Color(0xFF2B2734),
        onPrimary = Color(0xFF18131F),
        onBackground = Color(0xFFF8F5FC),
        onSurface = Color(0xFFF8F5FC)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

enum class AppScreen { HOME, APPS }

data class LaunchableApp(val label: String, val packageName: String)

@Composable
private fun FamiliarApp(refreshToken: Int, onRefresh: () -> Unit) {
    val context = LocalContext.current
    val store = remember { AppStore(context) }
    var screen by remember { mutableStateOf(AppScreen.HOME) }
    var showPromise by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    when (screen) {
        AppScreen.HOME -> HomeScreen(
            store = store,
            refreshToken = refreshToken,
            onRefresh = onRefresh,
            onPickApps = { screen = AppScreen.APPS },
            onPromise = { showPromise = true },
            onSettings = { showSettings = true }
        )
        AppScreen.APPS -> AppPickerScreen(store = store, onBack = { screen = AppScreen.HOME; onRefresh() })
    }

    if (showPromise) {
        PromiseDialog(store, onDismiss = { showPromise = false }, onSaved = { showPromise = false; onRefresh() })
    }
    if (showSettings) {
        SettingsDialog(store, onDismiss = { showSettings = false }, onSaved = { showSettings = false; onRefresh() })
    }
}

@Composable
private fun HomeScreen(
    store: AppStore,
    refreshToken: Int,
    onRefresh: () -> Unit,
    onPickApps: () -> Unit,
    onPromise: () -> Unit,
    onSettings: () -> Unit
) {
    val context = LocalContext.current
    val state = PersonalityEngine.state(store)
    val stage = PersonalityEngine.stage(state.daysToStart)
    var speech by remember(refreshToken) { mutableStateOf(PersonalityEngine.homeMessage(state)) }
    var remainingMs by remember(refreshToken) { mutableLongStateOf((store.studyEnd() - System.currentTimeMillis()).coerceAtLeast(0L)) }

    LaunchedEffect(store.studyEnd(), refreshToken) {
        val end = store.studyEnd()
        if (end > 0L) {
            while (System.currentTimeMillis() < end) {
                remainingMs = (end - System.currentTimeMillis()).coerceAtLeast(0L)
                delay(1000)
            }
            val done = store.completeStudyIfDue()
            if (done > 0) {
                speech = PersonalityEngine.studyFinished(done, store.studyMinutesToday())
                onRefresh()
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(Modifier.height(8.dp)) }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(R.drawable.resident2_face),
                    contentDescription = "Your digital familiar",
                    modifier = Modifier.size(76.dp).clip(CircleShape).background(Color.White),
                    contentScale = ContentScale.Crop
                )
                Column(Modifier.padding(start = 14.dp).weight(1f)) {
                    Text("OPERATION IRISHI", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text("${store.familiarName} · digital familiar", color = Color(0xFFAAA4B5))
                }
                TextButton(onClick = onSettings) { Text("⚙") }
            }
        }

        item {
            Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(PersonalityEngine.countdownLabel(state), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(5.dp))
                    Text("DEC 14 — DEC 17, 2026", fontWeight = FontWeight.Bold)
                    Text(stage.title, color = urgencyColor(stage.urgency), style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(14.dp))
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp)) {
                        Text(speech, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    }
                    Spacer(Modifier.height(10.dp))
                    TextButton(onClick = { speech = PersonalityEngine.homeMessage(PersonalityEngine.state(store)) }) {
                        Text("Poke him")
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("STUDIED", "${store.studyMinutesToday()}m", Modifier.weight(1f))
                StatCard("DOOR FIGHTS", "${store.blockAttemptsToday()}", Modifier.weight(1f))
                StatCard("CHAOS", "${store.chaosBypassesToday()}", Modifier.weight(1f))
            }
        }

        item {
            if (store.isStudyActive()) {
                ActiveRaidCard(
                    remainingMs = remainingMs,
                    onStop = {
                        AlarmTools.cancelStudyEnd(context)
                        val minutes = store.endStudyEarly()
                        speech = if (minutes > 0) "Raid ended early. $minutes minutes still count. We are not throwing useful work in the bin." else "Very dramatic. We lasted less than a minute. Again?"
                        onRefresh()
                    }
                )
            } else {
                Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text("START A RAID", fontWeight = FontWeight.Black)
                        Text("No giant life transformation. Sit down and attack one chunk.", color = Color(0xFFAAA4B5))
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(onClick = {
                                store.startStudy(25)
                                AlarmTools.scheduleStudyEnd(context, store.studyEnd())
                                speech = PersonalityEngine.studyStarted(25)
                                onRefresh()
                            }, modifier = Modifier.weight(1f)) { Text("25 min") }
                            Button(onClick = {
                                store.startStudy(50)
                                AlarmTools.scheduleStudyEnd(context, store.studyEnd())
                                speech = PersonalityEngine.studyStarted(50)
                                onRefresh()
                            }, modifier = Modifier.weight(1f)) { Text("50 min") }
                        }
                    }
                }
            }
        }

        if (store.hasPromise()) {
            item {
                Surface(shape = RoundedCornerShape(22.dp), color = if (store.isPromiseOverdue()) Color(0xFF3A232A) else MaterialTheme.colorScheme.surface) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text(if (store.isPromiseOverdue()) "TREATY VIOLATION" else "CURRENT TREATY", fontWeight = FontWeight.Black)
                        Text(store.promiseText(), style = MaterialTheme.typography.titleMedium)
                        Text("Due ${formatClock(store.promiseDue())}", color = Color(0xFFAAA4B5))
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { store.markPromiseKept(); speech = "You actually did it. I retract approximately 73% of the slander."; onRefresh() }) { Text("I did it") }
                            OutlinedButton(onClick = { store.clearPromise(); speech = "Treaty dissolved. Suspicious, but legally clean."; onRefresh() }) { Text("Cancel") }
                        }
                    }
                }
            }
        }

        item {
            Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("HE LIVES IN THE PHONE NOW", fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(8.dp))
                    Text("Random inspections are scheduled during the day. Give him Accessibility only if you want Door Guard to notice selected app openings.", color = Color(0xFFBBB5C4))
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onPromise, modifier = Modifier.fillMaxWidth()) { Text("Make him a promise") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onPickApps, modifier = Modifier.fillMaxWidth()) {
                        Text("Choose distraction apps (${store.selectedPackages().size})")
                    }
                    Spacer(Modifier.height(8.dp))
                    val enabled = isAccessibilityServiceEnabled(context)
                    OutlinedButton(
                        onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (enabled) "Door Guard is ON · tap for settings" else "Enable Door Guard")
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { store.setQuietMinutes(30); speech = "Thirty-minute ceasefire. Go be a mammal. I'll shut up."; onRefresh() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Give me 30 min of peace")
                    }
                }
            }
        }

        item {
            Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("FAMILIAR MEMORY", fontWeight = FontWeight.Black)
                    Text("${store.sessionsCompleted()} raids · ${store.totalStudyMinutes()} total study minutes · bond score ${store.relationshipScore()}", color = Color(0xFFBBB5C4))
                    Spacer(Modifier.height(6.dp))
                    Text("v0.1 keeps this memory only on your phone. No account. No analytics. No cloud brain yet.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF8F8999))
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(vertical = 14.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color(0xFF9E98AA), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun ActiveRaidCard(remainingMs: Long, onStop: () -> Unit) {
    val totalSeconds = (remainingMs / 1000L).coerceAtLeast(0L)
    val min = totalSeconds / 60
    val sec = totalSeconds % 60
    Surface(shape = RoundedCornerShape(22.dp), color = Color(0xFF262239)) {
        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("RAID IN PROGRESS", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
            Text(String.format(Locale.US, "%02d:%02d", min, sec), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black)
            Text("He is guarding the doors. You do the work.", color = Color(0xFFBBB5C4))
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onStop) { Text("End early") }
        }
    }
}

@Composable
private fun PromiseDialog(store: AppStore, onDismiss: () -> Unit, onSaved: () -> Unit) {
    val context = LocalContext.current
    var text by remember { mutableStateOf("") }
    var selectedMinutes by remember { mutableIntStateOf(30) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Make a treaty") },
        text = {
            Column {
                Text("Tell him what you are going to start. He will remember. This is legally unwise.")
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("e.g. Start Victorian poetry") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(15, 30, 60).forEach { m ->
                        OutlinedButton(onClick = { selectedMinutes = m }) { Text(if (selectedMinutes == m) "✓ $m" else "$m") }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (text.isNotBlank()) {
                    val due = System.currentTimeMillis() + selectedMinutes * 60_000L
                    store.setPromise(text, due)
                    AlarmTools.schedulePromise(context, due)
                    onSaved()
                }
            }) { Text("Sign it") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Run away") } }
    )
}

@Composable
private fun SettingsDialog(store: AppStore, onDismiss: () -> Unit, onSaved: () -> Unit) {
    var name by remember { mutableStateOf(store.familiarName) }
    var start by remember { mutableStateOf(store.examStart.toString()) }
    var end by remember { mutableStateOf(store.examEnd.toString()) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Familiar settings") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("His name") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = start, onValueChange = { start = it }, label = { Text("Earliest exam date") }, supportingText = { Text("YYYY-MM-DD") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = end, onValueChange = { end = it }, label = { Text("Latest exam date") }, supportingText = { Text("YYYY-MM-DD") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = Color(0xFFFFB4B4)) }
            }
        },
        confirmButton = {
            Button(onClick = {
                runCatching {
                    val s = LocalDate.parse(start)
                    val e = LocalDate.parse(end)
                    require(!e.isBefore(s))
                    store.setFamiliarName(name)
                    store.setExamWindow(s, e)
                }.onSuccess { onSaved() }.onFailure { error = "Check the dates. The end must not be before the start." }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun AppPickerScreen(store: AppStore, onBack: () -> Unit) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<LaunchableApp>>(emptyList()) }
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(store.selectedPackages()) }

    LaunchedEffect(Unit) { apps = loadLaunchableApps(context) }
    val filtered = remember(apps, search) {
        if (search.isBlank()) apps else apps.filter { it.label.contains(search, true) || it.packageName.contains(search, true) }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Back") }
            Column(Modifier.weight(1f)) {
                Text("DISTRACTION DOORS", fontWeight = FontWeight.Black)
                Text("Select only apps he should interrogate.", color = Color(0xFFAAA4B5), style = MaterialTheme.typography.bodySmall)
            }
        }
        OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("Find an app") }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(filtered, key = { it.packageName }) { app ->
                val checked = selected.contains(app.packageName)
                Row(
                    Modifier.fillMaxWidth().clickable {
                        store.setSelectedPackage(app.packageName, !checked)
                        selected = store.selectedPackages()
                    }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = checked, onCheckedChange = {
                        store.setSelectedPackage(app.packageName, it)
                        selected = store.selectedPackages()
                    })
                    Column(Modifier.padding(start = 10.dp).weight(1f)) {
                        Text(app.label, fontWeight = FontWeight.SemiBold)
                        Text(app.packageName, style = MaterialTheme.typography.bodySmall, color = Color(0xFF8F8999))
                    }
                }
                HorizontalDivider(color = Color(0xFF2B2734))
            }
        }
    }
}

private fun loadLaunchableApps(context: Context): List<LaunchableApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val results = if (Build.VERSION.SDK_INT >= 33) {
        pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
    } else {
        @Suppress("DEPRECATION")
        val legacy = pm.queryIntentActivities(intent, 0)
        legacy
    }
    return results.asSequence()
        .mapNotNull { r ->
            val pkg = r.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == context.packageName) return@mapNotNull null
            val label = r.loadLabel(pm)?.toString()?.trim().orEmpty().ifBlank { pkg.substringAfterLast('.') }
            LaunchableApp(label, pkg)
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
        .toList()
}

private fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val component = ComponentName(context, FamiliarAccessibilityService::class.java).flattenToString()
    val enabled = Settings.Secure.getInt(context.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
    if (!enabled) return false
    val setting = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return setting.split(':').any { it.equals(component, ignoreCase = true) }
}

private fun formatClock(millis: Long): String {
    val instant = java.time.Instant.ofEpochMilli(millis)
    return DateTimeFormatter.ofPattern("h:mm a").withLocale(Locale.getDefault()).withZone(java.time.ZoneId.systemDefault()).format(instant)
}

private fun urgencyColor(level: Int): Color = when (level) {
    1 -> Color(0xFF9DCDE3)
    2 -> Color(0xFFB9A7E8)
    3 -> Color(0xFFE0C279)
    4 -> Color(0xFFE7A46D)
    5 -> Color(0xFFFF8D79)
    else -> Color(0xFFFF6F91)
}
