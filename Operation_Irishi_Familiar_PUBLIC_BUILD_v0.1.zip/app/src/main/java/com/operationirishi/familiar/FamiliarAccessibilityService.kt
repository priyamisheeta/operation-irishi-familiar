package com.operationirishi.familiar

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class FamiliarAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName == this.packageName) return

        val store = AppStore(this)
        if (!store.isSelected(packageName)) return
        if (store.hasActivePass(packageName)) return

        val now = System.currentTimeMillis()
        if (now - store.lastGateLaunch() < 1800L) return
        store.setLastGateLaunch(now)
        store.recordBlockAttempt()

        val intent = Intent(this, GateActivity::class.java).apply {
            putExtra(GateActivity.EXTRA_PACKAGE, packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        }
        runCatching { startActivity(intent) }
    }

    override fun onInterrupt() = Unit
}
