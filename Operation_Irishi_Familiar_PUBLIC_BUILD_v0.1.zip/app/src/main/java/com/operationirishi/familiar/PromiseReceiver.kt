package com.operationirishi.familiar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PromiseReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val store = AppStore(context)
        if (store.hasPromise() && !store.promiseKept()) {
            NotificationKit.showMission(context, PersonalityEngine.promiseReminder(store.promiseText()), "Treaty enforcement")
        }
    }
}
