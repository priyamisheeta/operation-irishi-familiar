package com.operationirishi.familiar

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationKit {
    const val CHANNEL_CHECKINS = "familiar_checkins"
    const val CHANNEL_MISSION = "familiar_mission"
    const val ID_CHECKIN = 1201
    const val ID_MISSION = 1202

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_CHECKINS, "Familiar check-ins", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Random inspections, jokes, and interruptions from your familiar."
                }
            )
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_MISSION, "Mission events", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Study completions, promises, and time-sensitive mission events."
                }
            )
        }
    }

    private fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun mainPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(context, 55, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun actionPendingIntent(context: Context, action: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, NotificationActionReceiver::class.java).apply {
            this.action = action
        }
        return PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun showCheckIn(context: Context, text: String) {
        ensureChannels(context)
        if (!canNotify(context)) return
        val store = AppStore(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_CHECKINS)
            .setSmallIcon(R.drawable.ic_stat_familiar)
            .setContentTitle(store.familiarName)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(mainPendingIntent(context))
            .addAction(0, "Studying", actionPendingIntent(context, NotificationActionReceiver.ACTION_STUDYING, 101))
            .addAction(0, "Caught", actionPendingIntent(context, NotificationActionReceiver.ACTION_CAUGHT, 102))
            .addAction(0, "Real break", actionPendingIntent(context, NotificationActionReceiver.ACTION_BREAK, 103))
            .build()
        NotificationManagerCompat.from(context).notify(ID_CHECKIN, notification)
    }

    fun showMission(context: Context, text: String, title: String? = null) {
        ensureChannels(context)
        if (!canNotify(context)) return
        val store = AppStore(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_MISSION)
            .setSmallIcon(R.drawable.ic_stat_familiar)
            .setContentTitle(title ?: store.familiarName)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(mainPendingIntent(context))
            .build()
        NotificationManagerCompat.from(context).notify(ID_MISSION, notification)
    }
}
