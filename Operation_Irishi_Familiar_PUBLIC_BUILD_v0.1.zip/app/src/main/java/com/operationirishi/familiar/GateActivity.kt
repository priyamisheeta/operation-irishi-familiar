package com.operationirishi.familiar

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

class GateActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val targetPackage = intent.getStringExtra(EXTRA_PACKAGE) ?: run { finish(); return }
        val store = AppStore(this)
        val appLabel = runCatching {
            val info = packageManager.getApplicationInfo(targetPackage, 0)
            packageManager.getApplicationLabel(info).toString()
        }.getOrDefault(targetPackage.substringAfterLast('.'))
        val state = PersonalityEngine.state(store)
        val opening = PersonalityEngine.gateOpening(appLabel, store.blockAttemptsToday(), state.daysToStart)

        setContent {
            FamiliarGateTheme {
                GateScreen(
                    familiarName = store.familiarName,
                    appLabel = appLabel,
                    openingLine = opening,
                    onRequestPass = { reason, minutes ->
                        val decision = PersonalityEngine.judgeReason(reason)
                        if (decision.allowed) {
                            store.grantPass(targetPackage, minutes)
                            Toast.makeText(this, "${decision.line}  $minutes-minute visa.", Toast.LENGTH_LONG).show()
                            setResult(Activity.RESULT_OK)
                            finish()
                            null
                        } else {
                            decision.line
                        }
                    },
                    onChaos = {
                        store.recordChaosBypass()
                        store.grantPass(targetPackage, 5)
                        Toast.makeText(this, "I CHOOSE CHAOS recorded. Five minutes. I will remember this slander.", Toast.LENGTH_LONG).show()
                        finish()
                    },
                    onBackToMission = { goHome() }
                )
            }
        }
    }

    private fun goHome() {
        val home = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(home)
        finish()
    }

    companion object {
        const val EXTRA_PACKAGE = "target_package"
    }
}

@Composable
private fun FamiliarGateTheme(content: @Composable () -> Unit) {
    val scheme = androidx.compose.material3.darkColorScheme(
        primary = Color(0xFFB9A7E8),
        secondary = Color(0xFFD5C6F7),
        background = Color(0xFF17151C),
        surface = Color(0xFF211E29),
        onPrimary = Color(0xFF17151C),
        onBackground = Color(0xFFF8F5FC),
        onSurface = Color(0xFFF8F5FC)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
private fun GateScreen(
    familiarName: String,
    appLabel: String,
    openingLine: String,
    onRequestPass: (String, Int) -> String?,
    onChaos: () -> Unit,
    onBackToMission: () -> Unit
) {
    var reason by remember { mutableStateOf("") }
    var rejection by remember { mutableStateOf<String?>(null) }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.resident2_face),
                contentDescription = "$familiarName looking suspicious",
                modifier = Modifier.size(132.dp).clip(CircleShape).background(Color.White),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(18.dp))
            Text(familiarName.uppercase(), fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
            Text("DOOR GUARD · $appLabel", style = MaterialTheme.typography.labelMedium, color = Color(0xFFAAA4B5))
            Spacer(Modifier.height(18.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surface).padding(20.dp)
            ) {
                Text(openingLine, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = reason,
                onValueChange = { reason = it; rejection = null },
                label = { Text("Why are you opening it?") },
                placeholder = { Text("Be specific. He has paperwork.") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
            rejection?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Color(0xFFFFC4C4), textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(16.dp))
            Text("TEMPORARY VISA", style = MaterialTheme.typography.labelMedium, color = Color(0xFFAAA4B5))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(2, 5, 10, 20).forEach { minutes ->
                    Button(
                        onClick = {
                            val denied = onRequestPass(reason, minutes)
                            if (denied != null) rejection = denied
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = ButtonDefaults.ContentPadding
                    ) { Text("$minutes") }
                }
            }
            Spacer(Modifier.height(14.dp))
            Button(onClick = onBackToMission, modifier = Modifier.fillMaxWidth()) {
                Text("Fine. Take me back.")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onChaos, modifier = Modifier.fillMaxWidth()) {
                Text("I choose chaos · 5 min")
            }
            Spacer(Modifier.height(8.dp))
            Text("You can always override him. The point is conscious choice, not imprisonment.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF8F8999), textAlign = TextAlign.Center)
        }
    }
}
