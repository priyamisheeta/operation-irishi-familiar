package com.operationirishi.familiar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class StudyAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val store = AppStore(context)
        val completed = store.completeStudyIfDue()
        if (completed > 0) {
            val line = PersonalityEngine.studyFinished(completed, store.studyMinutesToday())
            NotificationKit.showMission(context, line, "Raid complete")
        }
    }
}
