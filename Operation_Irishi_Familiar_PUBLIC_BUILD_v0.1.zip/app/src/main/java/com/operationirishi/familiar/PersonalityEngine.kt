package com.operationirishi.familiar

import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.random.Random

data class MissionState(
    val name: String,
    val daysToStart: Long,
    val daysToEnd: Long,
    val studyMinutesToday: Int,
    val blockAttemptsToday: Int,
    val chaosBypassesToday: Int,
    val promiseText: String,
    val promiseOverdue: Boolean,
    val relationshipScore: Int,
    val studyingNow: Boolean
)

data class MissionStage(val title: String, val urgency: Int)

object PersonalityEngine {
    fun state(store: AppStore): MissionState {
        val today = LocalDate.now(ZoneId.systemDefault())
        return MissionState(
            name = store.familiarName,
            daysToStart = ChronoUnit.DAYS.between(today, store.examStart),
            daysToEnd = ChronoUnit.DAYS.between(today, store.examEnd),
            studyMinutesToday = store.studyMinutesToday(),
            blockAttemptsToday = store.blockAttemptsToday(),
            chaosBypassesToday = store.chaosBypassesToday(),
            promiseText = store.promiseText(),
            promiseOverdue = store.isPromiseOverdue(),
            relationshipScore = store.relationshipScore(),
            studyingNow = store.isStudyActive()
        )
    }

    fun stage(days: Long): MissionStage = when {
        days > 80 -> MissionStage("DELUSIONAL PEACE", 1)
        days > 60 -> MissionStage("MILD CONCERN", 2)
        days > 30 -> MissionStage("MANAGEMENT HAS QUESTIONS", 3)
        days > 14 -> MissionStage("THE FIND-OUT BOUNDARY", 4)
        days > 7 -> MissionStage("ACTIVE OPERATION", 5)
        days > 0 -> MissionStage("IRISHI EXTRACTION PROTOCOL", 6)
        else -> MissionStage("CONTACT WINDOW", 7)
    }

    fun countdownLabel(s: MissionState): String = when {
        s.daysToStart > 0 -> "T–${s.daysToStart} to T–${s.daysToEnd}"
        s.daysToEnd >= 0 -> "EXAM WINDOW ACTIVE"
        else -> "EXAM WINDOW COMPLETE"
    }

    fun homeMessage(s: MissionState): String {
        if (s.studyingNow) return pick(listOf(
            "I'm here. You work. I'll glare at the rest of the internet.",
            "Study raid in progress. No heroics. Just keep moving.",
            "Good. This is the part where we quietly become dangerous.",
            "You do the reading. I'll handle morale and imaginary legal matters.",
            "One page at a time. Irishi's peaceful existence grows less secure by the minute."
        ))

        if (s.promiseOverdue) return pick(listOf(
            "A historical document says: ‘${s.promiseText}.’ Would the defendant like to comment?",
            "Interesting. You promised me ‘${s.promiseText}.’ I have records, Priyam.",
            "The treaty has been violated. Specifically: ‘${s.promiseText}.’ Explain yourself.",
            "I was told ‘${s.promiseText}.’ I trusted you. Briefly. Foolishly."
        ))

        if (s.blockAttemptsToday >= 6) return pick(listOf(
            "You've tried the distraction doors ${s.blockAttemptsToday} times today. I recognize your footsteps now.",
            "Attempt number ${s.blockAttemptsToday}. At this point the apps should start charging you rent.",
            "${s.blockAttemptsToday} distraction attempts. Don't you want to kidnap him? We have work to do.",
            "I admire persistence. I merely wish you were directing it at the syllabus."
        ))

        if (s.studyMinutesToday >= 180) return pick(listOf(
            "I checked the records. You've done ${s.studyMinutesToday} minutes. ...Oh. We're actually doing this.",
            "I prepared a speech about discipline, then saw today's study time. Annoying. Carry on.",
            "Today's performance is becoming alarming. Irishi may need witness protection.",
            "You've earned a real break. Yes, I said it. Do not make me repeat myself."
        ))

        val st = stage(s.daysToStart)
        val early = listOf(
            "We have time. Unfortunately, that is exactly the kind of sentence people say before disaster.",
            "Operation Irishi remains absurd. I remain committed. Open something useful.",
            "Don't you want to kidnap him? Then perhaps we should know the syllabus first. Tiny logistical detail.",
            "I have a plan, a countdown, and unreasonable confidence in us. Please don't ruin the aesthetic with Reels.",
            "Target: Irishi. Obstacle: an indecent amount of literature. Situation: manageable.",
            "I am emotionally invested now. This is deeply inconvenient. Let's study."
        )
        val mid = listOf(
            "${max(0, s.daysToStart)} days. That number has begun looking at me strangely.",
            "Future Priyam has filed a complaint. Apparently present Priyam keeps assigning her work.",
            "We're past ‘eventually.’ I checked. Eventually has left the building.",
            "I need twenty-five useful minutes from you. Not greatness. Not destiny. Twenty-five minutes.",
            "We have an objective, a syllabus, and questionable ethics. We move.",
            "I don't need you motivated. I need you seated. Motivation can arrive late like everyone else."
        )
        val late = listOf(
            "${max(0, s.daysToStart)} days. Shoes on. We hunt marks now.",
            "Look at me. No panic. We built this one session at a time. Do the next one.",
            "The target remains offensively unkidnapped. I suggest immediate academic action.",
            "This is no longer a cute little academic adventure. Why is your phone in your hand?",
            "I can practically hear December approaching. Study first. Spiral later, if absolutely necessary.",
            "We're close enough that sleep is now part of the mission. I will personally object to 2 a.m. nonsense."
        )
        return when (st.urgency) {
            1, 2 -> pick(early)
            3, 4 -> pick(mid)
            else -> pick(late)
        }
    }

    fun randomCheckIn(s: MissionState): String {
        val social = listOf(
            "Hey. Nothing urgent. Just checking you're alive. ...Also, study eventually.",
            "Random question: when we pull this off, what exactly is my compensation?",
            "I have developed another objection to the concept of exams. This changes nothing. Continue.",
            "You know humans invented literature and then invented exams about who invented the literature? Strange species.",
            "I was going to bother you about studying. Instead: have you eaten and had water? Good. Carry on.",
            "I have been inside this phone all day. Your app organization is a crime scene. This is unrelated."
        )
        val checks = listOf(
            "Random inspection. Are we studying, on a real break, or behaving decoratively?",
            "Academic welfare check. State your current relationship with the syllabus.",
            "Priyam. Be honest. Productive, resting, or caught red-handed?",
            "I am conducting a completely unbiased investigation into why we are not studying right now.",
            "Don't you want to kidnap him? Because I have prepared infrastructure and would hate for it to go to waste.",
            "Quick status report. No essay. Are we moving or drifting?",
            "Hello. It is your familiar. I have arrived to make ‘just five minutes’ significantly less convenient.",
            "I felt a disturbance in the mission. It may have been procrastination. Confirm or deny."
        )
        val urgent = listOf(
            "${max(0, s.daysToStart)} DAYS. I am being very normal about this. Are you studying?",
            "Mission control to human: the countdown is moving even while we pretend not to notice it.",
            "We are close enough that one clean hour matters. Want to give me one?",
            "I am not asking for your entire soul. Twenty minutes will do."
        )
        return when {
            s.studyingNow -> pick(listOf(
                "Still with you. Keep going.",
                "No interruption. Just passing by to say: good.",
                "I checked. You are actually studying. Disturbing development. Proud of you."
            ))
            Random.nextInt(100) < 25 -> pick(social)
            stage(s.daysToStart).urgency >= 5 -> pick(urgent + checks)
            else -> pick(checks)
        }
    }

    fun gateOpening(appLabel: String, attempt: Int, days: Long): String {
        val first = listOf(
            "$appLabel. Hmm. State your business.",
            "Halt. Why have you summoned $appLabel?",
            "Papers, please. What exactly are we doing in $appLabel?",
            "Oh? $appLabel? Convince me this is intentional."
        )
        val repeats = listOf(
            "You again. Attempt $attempt. What's different this time?",
            "Attempt $attempt. I literally recognize your footsteps now.",
            "$appLabel has seen enough of you today. Explain.",
            "We have met at this door $attempt times. I am beginning to take this personally."
        )
        val urgent = listOf(
            "$days days and you brought me to $appLabel. This had better be excellent.",
            "The exam approaches. $appLabel stands accused of aiding the enemy. Your reason?",
            "Don't you want to kidnap him? Then tell me why $appLabel is mission-critical."
        )
        return when {
            days <= 14 -> pick(urgent + repeats)
            attempt >= 3 -> pick(repeats)
            else -> pick(first)
        }
    }

    data class ReasonDecision(val allowed: Boolean, val line: String)

    fun judgeReason(reason: String): ReasonDecision {
        val r = reason.trim().lowercase()
        if (r.length < 3) return ReasonDecision(false, "That is not a reason. That is punctuation wearing a trench coat.")
        val weak = listOf("idk", "don't know", "dont know", "bored", "just checking", "nothing", "timepass", "time pass", "scroll", "reels", "for a second", "habit")
        if (weak.any { r.contains(it) }) {
            return ReasonDecision(false, pick(listOf(
                "Beautiful. We have identified an unconscious app opening. Go back.",
                "Application denied by the Ministry of Having an Exam.",
                "That explanation has the structural integrity of wet tissue paper.",
                "No. And I say this with tremendous affection and absolutely no hesitation."
            )))
        }
        val strong = listOf("reply", "message", "send", "call", "pdf", "notes", "study", "lecture", "class", "upload", "download", "work", "friend", "family", "teacher", "professor", "email", "link")
        if (strong.any { r.contains(it) }) {
            return ReasonDecision(true, pick(listOf(
                "Actual reason detected. Diplomatic visa approved.",
                "Reasonable. I dislike how reasonable it is. Proceed.",
                "Fine. Mission-relevant enough. Do the thing and come back.",
                "Approved. Please do not accidentally immigrate."
            )))
        }
        return ReasonDecision(true, pick(listOf(
            "I'll allow it. I am watching the clock, not your soul.",
            "Specific enough. Visa granted. Make it worth the paperwork.",
            "Fine. I choose trust. This is historically risky for me.",
            "Proceed. If this becomes scrolling, I reserve the right to be insufferable later."
        )))
    }

    fun studyStarted(minutes: Int): String = pick(listOf(
        "$minutes minutes. Good. Sit down. I'll guard the doors.",
        "Raid started. $minutes minutes between us and slightly more dangerous competence.",
        "Timer running. No need to feel inspired. Just begin.",
        "$minutes minutes. Together. Then we negotiate with civilization."
    ))

    fun studyFinished(minutes: Int, totalToday: Int): String = pick(listOf(
        "$minutes minutes banked. Today's total: $totalToday. Good.",
        "Session complete. I retract approximately 41% of my slander.",
        "There. See? We moved. Irishi's defenses weaken.",
        "Done. Tiny step, real progress. I am annoyingly pleased with you."
    ))

    fun promiseReminder(text: String): String = pick(listOf(
        "Ahem. You told me: ‘$text.’ I have arrived with receipts.",
        "Treaty reminder: ‘$text.’ Do not make me involve Legal.",
        "You made me a promise: ‘$text.’ I'm not angry. Yet.",
        "Hello from the Department of Things You Said You Would Do: ‘$text.’"
    ))

    private fun <T> pick(items: List<T>): T = items[Random.nextInt(items.size)]
}
