package com.operationirishi.familiar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val store = AppStore(context)
        when (intent?.action) {
            ACTION_STUDYING -> NotificationKit.showMission(context, "Good. I will return to my lair. Disturb me if civilization collapses.")
            ACTION_CAUGHT -> NotificationKit.showMission(context, "Thank you for your honesty. Unfortunately honesty awards zero marks. Give me fifteen useful minutes.")
            ACTION_BREAK -> {
                store.setQuietMinutes(30)
                NotificationKit.showMission(context, "Real break authorized. Thirty minutes. Go be a mammal. I'll shut up.")
            }
        }
    }

    companion object {
        const val ACTION_STUDYING = "com.operationirishi.familiar.action.STUDYING"
        const val ACTION_CAUGHT = "com.operationirishi.familiar.action.CAUGHT"
        const val ACTION_BREAK = "com.operationirishi.familiar.action.BREAK"
    }
}
