package com.operationirishi.familiar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        NotificationKit.ensureChannels(context)
        CheckInScheduler.scheduleNext(context)
        val store = AppStore(context)
        if (store.isStudyActive()) AlarmTools.scheduleStudyEnd(context, store.studyEnd())
        if (store.hasPromise() && store.promiseDue() > System.currentTimeMillis()) {
            AlarmTools.schedulePromise(context, store.promiseDue())
        }
    }
}
