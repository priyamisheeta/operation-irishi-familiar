package com.operationirishi.familiar

import android.content.Context
import java.time.LocalDate
import java.time.ZoneId

class AppStore(context: Context) {
    private val prefs = context.getSharedPreferences("familiar_store", Context.MODE_PRIVATE)

    val familiarName: String
        get() = prefs.getString("familiar_name", "Nex") ?: "Nex"

    fun setFamiliarName(name: String) {
        val clean = name.trim().take(24)
        if (clean.isNotBlank()) prefs.edit().putString("familiar_name", clean).apply()
    }

    val examStart: LocalDate
        get() = runCatching { LocalDate.parse(prefs.getString("exam_start", "2026-12-14")) }
            .getOrElse { LocalDate.of(2026, 12, 14) }

    val examEnd: LocalDate
        get() = runCatching { LocalDate.parse(prefs.getString("exam_end", "2026-12-17")) }
            .getOrElse { LocalDate.of(2026, 12, 17) }

    fun setExamWindow(start: LocalDate, end: LocalDate) {
        val safeEnd = if (end.isBefore(start)) start else end
        prefs.edit().putString("exam_start", start.toString()).putString("exam_end", safeEnd.toString()).apply()
    }

    val installedAt: Long
        get() {
            val existing = prefs.getLong("installed_at", 0L)
            if (existing != 0L) return existing
            val now = System.currentTimeMillis()
            prefs.edit().putLong("installed_at", now).apply()
            return now
        }

    fun selectedPackages(): Set<String> = prefs.getStringSet("selected_packages", emptySet())?.toSet() ?: emptySet()

    fun setSelectedPackage(packageName: String, selected: Boolean) {
        val set = selectedPackages().toMutableSet()
        if (selected) set.add(packageName) else set.remove(packageName)
        prefs.edit().putStringSet("selected_packages", set).apply()
    }

    fun isSelected(packageName: String): Boolean = selectedPackages().contains(packageName)

    fun grantPass(packageName: String, minutes: Int) {
        val until = System.currentTimeMillis() + minutes.coerceIn(1, 120) * 60_000L
        prefs.edit().putLong("pass_$packageName", until).apply()
    }

    fun passUntil(packageName: String): Long = prefs.getLong("pass_$packageName", 0L)
    fun hasActivePass(packageName: String): Boolean = passUntil(packageName) > System.currentTimeMillis()

    private fun todayKey(): String = LocalDate.now(ZoneId.systemDefault()).toString()

    private fun ensureDailyReset() {
        val today = todayKey()
        val stored = prefs.getString("day_key", "")
        if (stored != today) {
            prefs.edit()
                .putString("day_key", today)
                .putInt("study_minutes_today", 0)
                .putInt("block_attempts_today", 0)
                .putInt("chaos_bypasses_today", 0)
                .apply()
        }
    }

    fun studyMinutesToday(): Int {
        ensureDailyReset()
        return prefs.getInt("study_minutes_today", 0)
    }

    fun totalStudyMinutes(): Int = prefs.getInt("study_minutes_total", 0)
    fun sessionsCompleted(): Int = prefs.getInt("sessions_completed", 0)

    fun blockAttemptsToday(): Int {
        ensureDailyReset()
        return prefs.getInt("block_attempts_today", 0)
    }

    fun recordBlockAttempt() {
        ensureDailyReset()
        prefs.edit().putInt("block_attempts_today", blockAttemptsToday() + 1).apply()
    }

    fun recordChaosBypass() {
        ensureDailyReset()
        prefs.edit().putInt("chaos_bypasses_today", prefs.getInt("chaos_bypasses_today", 0) + 1).apply()
    }

    fun chaosBypassesToday(): Int {
        ensureDailyReset()
        return prefs.getInt("chaos_bypasses_today", 0)
    }

    fun startStudy(minutes: Int) {
        val now = System.currentTimeMillis()
        val clamped = minutes.coerceIn(1, 240)
        prefs.edit()
            .putLong("study_start", now)
            .putLong("study_end", now + clamped * 60_000L)
            .putInt("study_planned_minutes", clamped)
            .apply()
    }

    fun studyStart(): Long = prefs.getLong("study_start", 0L)
    fun studyEnd(): Long = prefs.getLong("study_end", 0L)
    fun studyPlannedMinutes(): Int = prefs.getInt("study_planned_minutes", 0)
    fun isStudyActive(): Boolean = studyEnd() > System.currentTimeMillis()

    fun completeStudyIfDue(): Int {
        val end = studyEnd()
        if (end == 0L || end > System.currentTimeMillis()) return 0
        val planned = studyPlannedMinutes().coerceAtLeast(1)
        return finishStudy(planned)
    }

    fun endStudyEarly(): Int {
        val start = studyStart()
        if (start == 0L) return 0
        val elapsed = ((System.currentTimeMillis() - start) / 60_000L).toInt().coerceAtLeast(0)
        return finishStudy(elapsed)
    }

    private fun finishStudy(minutes: Int): Int {
        if (studyEnd() == 0L && studyStart() == 0L) return 0
        ensureDailyReset()
        val m = minutes.coerceAtLeast(0)
        val editor = prefs.edit()
            .putLong("study_start", 0L)
            .putLong("study_end", 0L)
            .putInt("study_planned_minutes", 0)
        if (m > 0) {
            editor
                .putInt("study_minutes_today", studyMinutesToday() + m)
                .putInt("study_minutes_total", totalStudyMinutes() + m)
                .putInt("sessions_completed", sessionsCompleted() + 1)
                .putLong("last_study_completed", System.currentTimeMillis())
        }
        editor.apply()
        return m
    }

    fun setPromise(text: String, dueMillis: Long) {
        prefs.edit()
            .putString("promise_text", text.trim().take(120))
            .putLong("promise_due", dueMillis)
            .putBoolean("promise_kept", false)
            .apply()
    }

    fun promiseText(): String = prefs.getString("promise_text", "") ?: ""
    fun promiseDue(): Long = prefs.getLong("promise_due", 0L)
    fun promiseKept(): Boolean = prefs.getBoolean("promise_kept", false)
    fun hasPromise(): Boolean = promiseText().isNotBlank() && promiseDue() > 0L && !promiseKept()
    fun isPromiseOverdue(): Boolean = hasPromise() && promiseDue() < System.currentTimeMillis()

    fun markPromiseKept() {
        if (hasPromise()) {
            prefs.edit().putBoolean("promise_kept", true).putLong("last_promise_kept", System.currentTimeMillis()).apply()
        }
    }

    fun clearPromise() {
        prefs.edit().remove("promise_text").remove("promise_due").remove("promise_kept").apply()
    }

    fun quietUntil(): Long = prefs.getLong("quiet_until", 0L)
    fun setQuietMinutes(minutes: Int) {
        prefs.edit().putLong("quiet_until", System.currentTimeMillis() + minutes.coerceIn(1, 240) * 60_000L).apply()
    }
    fun isQuiet(): Boolean = quietUntil() > System.currentTimeMillis()

    fun lastGateLaunch(): Long = prefs.getLong("last_gate_launch", 0L)
    fun setLastGateLaunch(now: Long) = prefs.edit().putLong("last_gate_launch", now).apply()

    fun relationshipScore(): Int {
        val days = ((System.currentTimeMillis() - installedAt) / 86_400_000L).toInt().coerceAtLeast(0)
        return days * 2 + sessionsCompleted() * 3 + (totalStudyMinutes() / 60)
    }
}
