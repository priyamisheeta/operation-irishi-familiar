package com.operationirishi.familiar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CheckInReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val store = AppStore(context)
        if (!store.isQuiet()) {
            val state = PersonalityEngine.state(store)
            NotificationKit.showCheckIn(context, PersonalityEngine.randomCheckIn(state))
        }
        CheckInScheduler.scheduleNext(context)
    }
}
