# Operation Irishi Familiar — v0.1

A privacy-first Android prototype of the user's sassy digital familiar.

## What already works
- December 14–17, 2026 exam-window countdown with escalating urgency stages.
- Resident-2 visual authority used as the first face.
- Proactive random "inspections" during the day.
- Study raids (25 / 50 minutes), completion tracking, and daily minutes.
- Promises: choose a topic and a short deadline; the familiar remembers and calls you out.
- Distraction Door Guard: select launchable apps; Android Accessibility detects only window/app changes, never reads screen text.
- Opening a selected app triggers a reason gate with temporary 2/5/10/20-minute visas.
- Local bullshit detector plus a deliberate "I choose chaos" bypass so the user always keeps agency.
- Persistent local memory for counts, study minutes, promises, passes, and familiar relationship progress.
- All data stays on-device in SharedPreferences. No account, server, analytics, or cloud AI in v0.1.

## First install
1. Open this folder in Android Studio Quail 4 (or newer).
2. Let Gradle sync and install Android SDK 36 if prompted.
3. Run the app on your Android phone with USB debugging, or Build > Build APK(s) and install the APK.
4. On first launch, grant notifications.
5. Tap "Enable door guard" and enable Familiar under Accessibility. The service is deliberately configured with `canRetrieveWindowContent=false`.
6. Tap "Choose distraction apps" and select the apps you want him to interrogate.

## Important prototype behavior
Android can always let the device owner disable Accessibility or uninstall the app. That is intentional. The familiar is friction, not a prison.

## Next iterations
- Real expression pack (angry, smug, sleepy, proud, panicked, soft, murderous countdown, etc.).
- Better local long-term memory and running jokes.
- Free-form conversational AI layer while preserving the local core.
- Floating micro-manifestations / widgets.
- More contextual phone-event commentary (charging, battery, repeated opens, etc.).
